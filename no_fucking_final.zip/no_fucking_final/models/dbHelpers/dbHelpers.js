const dbConnector = require('../dbConnect/db');

const addNewUser = async user => {
    console.log(user);
    await dbConnector.connect().query(`INSERT INTO KHACH_HANG(TAI_KHOAN,MAT_KHAU,TEN_KH,EMAIL,SDT) VALUES ( '${user.username}',  
    '${user.password}',  '${user.name}',  '${user.email}','${user.phoneNumber}')`, (error, results) => {
        if (error) {
            console.log(error)
        }
        // if(results.rows.length == 0)
        // {
        //   response.send({exist: false })
        // }
        else {
            console.log(results)
            return results
        }

    })
}

const userAuthentication = async( user) => {

    console.log('user log in', user);
    // await dbConnector.connect().;
    return await dbConnector.connect().query(`SELECT * FROM KHACH_HANG WHERE TAI_KHOAN='${user.username}'`, (error, results) => {
        if (error) {
            console.log(error)
        }
        else {
            //console.log(results.rows)
            // return '123'
            return results;
        }

    })
}

const adminAuthentication = async user => {
    await dbConnector.query(`SELECT * FROM NGUOI_BAN WHERE TAI_KHOAN='${user.username}'`, (error, results) => {
        if (error) {
            console.log(error)
        }
        else {

            return results.rows
        }

    })
}
module.exports = {
    addNewUser, userAuthentication, adminAuthentication
}