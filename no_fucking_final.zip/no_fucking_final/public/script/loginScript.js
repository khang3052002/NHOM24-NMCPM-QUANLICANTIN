$("#admin-login-btn").click(()=>{
    var ajax1 = $.ajax({
        type: 'post',
        url: `/sign-in`,
        data: $('#admin-login-form').serialize(),
        success: function (data) {
            window.alert(data);
            window.location.reload();
        }
    })
})

$("#user-login-btn").click(()=>{
    var ajax1 = $.ajax({
        type: 'post',
        url: `/sign-in`,
        data: $('#user-login-form').serialize(),
        success: function (data) {
            window.alert(data);
            window.location.reload();
        }
    })
})